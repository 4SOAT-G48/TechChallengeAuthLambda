import { APIGatewayProxyEventBase } from 'aws-lambda';
import sendResponse from '../utils/api';
import { awsConfig, cognito } from '../constants';

interface RegisterEvent {
    body: string; 
}

export async function register(event: APIGatewayProxyEventBase<RegisterEvent>): Promise<any> {
    try {
        const { email, password } = JSON.parse(event.body);

        const result = await cognito
            .adminCreateUser({
                UserPoolId: awsConfig.USER_POOL,
                Username: email,
                UserAttributes: [
                    {
                        Name: 'email',
                        Value: email,
                    },
                    {
                        Name: 'email_verified',
                        Value: 'true',
                    },
                ],
                MessageAction: 'SUPPRESS',
            })
            .promise();

        if (result.User) {
            await cognito
                .adminSetUserPassword({
                    Password: password,
                    UserPoolId: awsConfig.USER_POOL,
                    Username: email,
                    Permanent: true,
                })
                .promise();
        }

        return sendResponse(200, { result });
    } catch (error) {
        console.error(error);
        return sendResponse(400, error);
    }
};